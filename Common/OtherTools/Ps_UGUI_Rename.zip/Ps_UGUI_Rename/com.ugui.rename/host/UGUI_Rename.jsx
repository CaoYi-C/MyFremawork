#target photoshop

// 定义 UGUI 前缀列表
var UGUI_PREFIXES = [
    "btn_", "txt_", "img_", "icon_", "bg_", "panel_",
    "scroll_", "input_", "toggle_", "slider_", "progress_",
    "group_", "item_", "fx_", "anim_", "mask_", "root_"
];

// 测试函数:检查前端能否调用后台
function ping() {
    return "pong";
}

// 主入口函数 - params 是 JS 对象(由前端直接构造对象字面量传过来,不是 JSON 字符串)
// 之前是 renameSelectedLayers(paramsJson) + JSON.parse,因 ExtendScript (ECMAScript 3) 没有
// 内置 JSON 且其 eval 对复杂 JSON 解析有兼容问题("应为: ]" 错误),改为直接接对象最稳
function renameSelectedLayers(params) {
    // 调试输出(可在 ExtendScript Toolkit 中查看)
    $.writeln("renameSelectedLayers called with prefix: " + params.prefix);

    var prefix = params.prefix;
    var options = {
        replaceOldPrefix: params.replaceOldPrefix,
        toLowerCase: params.toLowerCase,
        spaceToUnderline: params.spaceToUnderline,
        recursive: params.recursive
    };

    if (!app.documents.length) {
        return "错误:请先打开一个 PSD 文档。";
    }
    if (!prefix) {
        return "错误:前缀不能为空。";
    }
    prefix = trim(prefix);
    if (prefix === "") {
        return "错误:前缀不能为空。";
    }
    if (prefix.charAt(prefix.length - 1) !== "_") {
        prefix += "_";
    }

    var doc = app.activeDocument;
    var selectedIds = getSelectedLayerIds();
    if (!selectedIds || selectedIds.length === 0) {
        return "错误:请先选择一个或多个图层。";
    }

    var count = 0;
    try {
        for (var i = 0; i < selectedIds.length; i++) {
            selectLayerById(selectedIds[i], false);
            var layer = doc.activeLayer;
            if (options.recursive && layer.typename === "LayerSet") {
                count += renameLayerRecursive(layer, prefix, options);
            } else {
                renameOneLayer(layer, prefix, options);
                count++;
            }
        }
        restoreSelectionByIds(selectedIds);
        return "完成:已处理 " + count + " 个图层,前缀为:" + prefix;
    } catch (e) {
        try { restoreSelectionByIds(selectedIds); } catch (er) {}
        return "重命名失败:\n" + e.message;
    }
}

// 递归处理图层组
function renameLayerRecursive(layer, prefix, options) {
    var count = 0;
    renameOneLayer(layer, prefix, options);
    count++;
    if (layer.typename === "LayerSet") {
        for (var i = 0; i < layer.layers.length; i++) {
            count += renameLayerRecursive(layer.layers[i], prefix, options);
        }
    }
    return count;
}

function renameOneLayer(layer, prefix, options) {
    var oldName = layer.name;
    var newBaseName = normalizeName(oldName, options);
    layer.name = prefix + newBaseName;
}

function normalizeName(name, options) {
    var result = trim(name);
    if (options.replaceOldPrefix) {
        var lowerName = result.toLowerCase();
        for (var i = 0; i < UGUI_PREFIXES.length; i++) {
            var p = UGUI_PREFIXES[i].toLowerCase();
            if (lowerName.indexOf(p) === 0) {
                result = result.substring(p.length);
                break;
            }
        }
    }
    result = trim(result);
    if (options.spaceToUnderline) {
        result = result.replace(/\s+/g, "_");
    }
    result = result.replace(/_+/g, "_");
    result = result.replace(/^_+/, "");
    result = result.replace(/_+$/, "");
    if (options.toLowerCase) {
        result = result.toLowerCase();
    }
    if (result === "") {
        result = "unnamed";
    }
    return result;
}

function trim(str) {
    return String(str).replace(/^\s+|\s+$/g, "");
}

function getSelectedLayerIds() {
    var ids = [];
    var ref = new ActionReference();
    ref.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("targetLayersIDs"));
    ref.putEnumerated(charIDToTypeID("Dcmn"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
    try {
        var desc = executeActionGet(ref);
        if (desc.hasKey(stringIDToTypeID("targetLayersIDs"))) {
            var list = desc.getList(stringIDToTypeID("targetLayersIDs"));
            for (var i = 0; i < list.count; i++) {
                ids.push(list.getReference(i).getIdentifier());
            }
            return ids;
        }
    } catch (e) {}
    try {
        var ref2 = new ActionReference();
        ref2.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("LyrI"));
        ref2.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));
        var desc2 = executeActionGet(ref2);
        ids.push(desc2.getInteger(charIDToTypeID("LyrI")));
    } catch (e2) {}
    return ids;
}

function selectLayerById(id, add) {
    var desc = new ActionDescriptor();
    var ref = new ActionReference();
    ref.putIdentifier(charIDToTypeID("Lyr "), id);
    desc.putReference(charIDToTypeID("null"), ref);
    if (add) {
        desc.putEnumerated(stringIDToTypeID("selectionModifier"),
            stringIDToTypeID("selectionModifierType"),
            stringIDToTypeID("addToSelection"));
    }
    desc.putBoolean(charIDToTypeID("MkVs"), false);
    executeAction(charIDToTypeID("slct"), desc, DialogModes.NO);
}

function restoreSelectionByIds(ids) {
    if (!ids || ids.length === 0) return;
    selectLayerById(ids[0], false);
    for (var i = 1; i < ids.length; i++) {
        selectLayerById(ids[i], true);
    }
}