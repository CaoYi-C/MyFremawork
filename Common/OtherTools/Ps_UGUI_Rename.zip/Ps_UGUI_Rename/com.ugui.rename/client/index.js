// 获取 CSInterface 实例,用于前端与 ExtendScript 通信
var csInterface = new CSInterface();

// 获取 DOM 元素
var cbReplace = document.getElementById('cbReplace');
var cbLower = document.getElementById('cbLower');
var cbSpace = document.getElementById('cbSpace');
var cbRecursive = document.getElementById('cbRecursive');
var customPrefixInput = document.getElementById('customPrefix');
var applyCustomBtn = document.getElementById('applyCustom');

// 为所有带 'data-prefix' 属性的按钮添加点击事件
var allBtns = document.querySelectorAll('[data-prefix]');
for (var i = 0; i < allBtns.length; i++) {
  allBtns[i].addEventListener('click', function(e) {
    var btn = e.currentTarget;
    var prefix = btn.getAttribute('data-prefix');
    // 调用后台方法,并传递选项
    callRename(prefix);
  });
}

// 为"应用"按钮添加事件
if (applyCustomBtn) {
  applyCustomBtn.addEventListener('click', function() {
    var prefix = customPrefixInput.value;
    if (prefix && prefix.trim()) {
      callRename(prefix);
    } else {
      alert('请输入自定义前缀');
    }
  });
}

/**
 * 调用后台 ExtendScript 进行重命名
 * 直接构造 ExtendScript 兼容的 JS 对象字面量字符串传过去
 * (ExtendScript 没有内置 JSON,且其 eval 解析有兼容问题,走对象字面量最稳)
 */
function callRename(prefix) {
  var replaceOldPrefix = cbReplace.checked;
  var toLowerCase = cbLower.checked;
  var spaceToUnderline = cbSpace.checked;
  var recursive = cbRecursive.checked;
  // 用 JSON.stringify 安全处理 prefix 字符串(转义引号/反斜杠/换行等)
  var paramStr = '{prefix:' + JSON.stringify(prefix) +
    ',replaceOldPrefix:' + replaceOldPrefix +
    ',toLowerCase:' + toLowerCase +
    ',spaceToUnderline:' + spaceToUnderline +
    ',recursive:' + recursive +
  '}';
  // evalScript 会把整个字符串当 ExtendScript 代码执行
  csInterface.evalScript('renameSelectedLayers(' + paramStr + ')', function(result) {
    if (result && /^(错误|重命名失败)/.test(result)) { // 成功静默,只有错误才弹窗
      alert(result);
    }
  });
}